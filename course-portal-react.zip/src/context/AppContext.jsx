import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { defaultCourses, defaultStudents, defaultAdmins } from '../data/mockData'

const AppCtx = createContext(null)

const STORAGE_KEY = 'course-portal-data-v1'

function loadInitial() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw)
      return parsed
    }
  } catch {}
  // seed from defaults
  const seed = {
    courses: defaultCourses,
    students: defaultStudents,
    admins: defaultAdmins,
    registrations: [], // derive from students.courses
    currentUser: null
  }
  seed.registrations = seed.students.flatMap(s => s.courses.map(code => ({ studentId: s.id, courseCode: code })))
  updateSeatsTaken(seed)
  return seed
}

function updateSeatsTaken(state) {
  state.courses.forEach(c => c.seatsTaken = 0)
  state.registrations.forEach(r => {
    const c = state.courses.find(x => x.code === r.courseCode)
    if (c) c.seatsTaken += 1
  })
}

export function AppProvider({ children }) {
  const [state, setState] = useState(loadInitial())

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  }, [state])

  const login = (email, password, role) => {
    if (role === 'admin') {
      const admin = state.admins.find(a => a.email === email && a.password === password)
      if (admin) {
        setState(s => ({ ...s, currentUser: { email: admin.email, role: 'admin', name: admin.name } }))
        return { ok: true }
      }
      return { ok: false, msg: 'Invalid admin credentials' }
    } else {
      const student = state.students.find(u => (u.email === email || u.id === email) && u.password === password)
      if (student) {
        setState(s => ({ ...s, currentUser: { email: student.email, id: student.id, role: 'student', name: student.name } }))
        return { ok: true }
      }
      return { ok: false, msg: 'Invalid student credentials' }
    }
  }

  const logout = () => setState(s => ({ ...s, currentUser: null }))

  // Course management
  const addCourse = (course) => {
    setState(s => {
      if (s.courses.some(c => c.code === course.code)) return s
      const next = { ...s, courses: [...s.courses, { ...course, seatsTaken: 0 }] }
      return next
    })
  }

  const deleteCourse = (code) => {
    setState(s => {
      const registrations = s.registrations.filter(r => r.courseCode !== code)
      const courses = s.courses.filter(c => c.code !== code)
      const students = s.students.map(st => ({ ...st, courses: st.courses.filter(cc => cc !== code) }))
      const next = { ...s, courses, registrations, students }
      updateSeatsTaken(next)
      return next
    })
  }

  // Student course ops
  const addCourseToStudent = (studentId, code) => {
    setState(s => {
      const course = s.courses.find(c => c.code === code)
      if (!course) return s
      const seatsLeft = course.seatsAvailable - course.seatsTaken
      const already = s.registrations.find(r => r.studentId === studentId && r.courseCode === code)
      if (already || seatsLeft <= 0) return s
      const registrations = [...s.registrations, { studentId, courseCode: code }]
      const students = s.students.map(st => st.id === studentId ? { ...st, courses: Array.from(new Set([...(st.courses || []), code])) } : st)
      const next = { ...s, registrations, students }
      updateSeatsTaken(next)
      return next
    })
  }

  const removeCourseFromStudent = (studentId, code) => {
    setState(s => {
      const registrations = s.registrations.filter(r => !(r.studentId === studentId && r.courseCode === code))
      const students = s.students.map(st => st.id === studentId ? { ...st, courses: st.courses.filter(cc => cc !== code) } : st)
      const next = { ...s, registrations, students }
      updateSeatsTaken(next)
      return next
    })
  }

  const value = useMemo(() => ({
    ...state,
    login,
    logout,
    addCourse,
    deleteCourse,
    addCourseToStudent,
    removeCourseFromStudent,
  }), [state])

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>
}

export function useApp(){ return useContext(AppCtx) }
