import React, { useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

export default function MarksChart({ marks={} }){
  const data = useMemo(()=> Object.entries(marks).map(([k,v]) => ({ subject:k, marks:v })), [marks])
  return (
    <div className="card">
      <h3 style={{marginTop:0}}>Marks</h3>
      <div style={{width:'100%', height:320}}>
        <ResponsiveContainer>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="subject" />
            <YAxis domain={[0,100]} />
            <Tooltip />
            <Bar dataKey="marks" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
