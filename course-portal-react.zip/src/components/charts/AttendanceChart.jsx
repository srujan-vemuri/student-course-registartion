import React from 'react'
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function AttendanceChart({ value=0 }){
  const data = [
    { name:'Present', value },
    { name:'Absent', value: Math.max(0, 100 - value) }
  ]

  return (
    <div className="card">
      <h3 style={{marginTop:0}}>Attendance</h3>
      <div style={{width:'100%', height:300}}>
        <ResponsiveContainer>
          <PieChart>
            <Pie dataKey="value" data={data} outerRadius={110} label />
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
