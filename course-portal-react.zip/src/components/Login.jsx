import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'

function randomCaptcha(){
  // 5-char alphanumeric, easily readable
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let s = ''
  for(let i=0;i<5;i++) s += chars[Math.floor(Math.random()*chars.length)]
  return s
}

export default function Login(){
  const { login } = useApp()
  const nav = useNavigate()
  const [role, setRole] = useState('student')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [captcha, setCaptcha] = useState(randomCaptcha())
  const [captchaInput, setCaptchaInput] = useState('')
  const [error, setError] = useState('')

  const canSubmit = useMemo(()=> email && password && captchaInput.toUpperCase() === captcha, [email,password,captcha,captchaInput])

  const handleSubmit = (e)=>{
    e.preventDefault()
    setError('')
    if(captchaInput.toUpperCase() !== captcha){
      setError('CAPTCHA does not match.')
      return
    }
    const res = login(email.trim(), password.trim(), role)
    if(res.ok){
      nav(role === 'admin' ? '/admin' : '/user')
    }else{
      setError(res.msg || 'Login failed')
      setCaptcha(randomCaptcha())
      setCaptchaInput('')
    }
  }

  return (
    <div className="login-wrap">
      <div className="card login-card">
        <div style={{textAlign:'center', marginBottom:12}}>
          <div className="login-title">Course Management & Student Portal</div>
          <div className="login-sub">Please sign in to continue</div>
        </div>

        <form onSubmit={handleSubmit}>
          <label className="label">Login as</label>
          <div style={{display:'flex', gap:8, marginBottom:8}}>
            <button type="button" className={`btn ${role==='student'?'btn-ghost':''}`} onClick={()=>setRole('student')}>Student</button>
            <button type="button" className={`btn ${role==='admin'?'btn-ghost':''}`} onClick={()=>setRole('admin')}>Admin</button>
          </div>

          <label className="label">{role==='admin'?'Admin Email':'Email or Student ID'}</label>
          <input className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder={role==='admin'?'admin@college.edu':'aryan@college.edu or S101'} />

          <label className="label">Password</label>
          <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder={role==='admin'?'admin123':'e.g. aryan123'} />

          <label className="label">CAPTCHA</label>
          <div style={{display:'flex', alignItems:'center', marginBottom:12}}>
            <div className="captcha-box">{captcha}</div>
            <button type="button" className="btn btn-ghost" onClick={()=>setCaptcha(randomCaptcha())}>Refresh</button>
          </div>
          <input className="input" value={captchaInput} onChange={e=>setCaptchaInput(e.target.value)} placeholder="Type the code above" />

          {error && <div style={{color:'#e74c3c', fontWeight:700, marginTop:8}}>{error}</div>}

          <div style={{marginTop:14}}>
            <button className="btn btn-primary" disabled={!canSubmit}>Login</button>
          </div>
        </form>

        <div style={{marginTop:14, fontSize:12, color:'#666'}}>
          <div><b>Admin:</b> admin@college.edu / admin123</div>
          <div><b>Students:</b> aryan@college.edu(priya/rohan/neha) / aryan123 ... or use ID S101 with password</div>
        </div>
      </div>
    </div>
  )
}
