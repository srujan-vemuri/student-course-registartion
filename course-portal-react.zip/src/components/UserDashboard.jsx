import React, { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext'
import { useNavigate } from 'react-router-dom'
import AttendanceChart from './charts/AttendanceChart'
import MarksChart from './charts/MarksChart'

function Timetable({ courses }){
  // Simple weekly view
  const days = ['Mon','Tue','Wed','Thu','Fri']
  const rows = days.map(d => {
    const items = courses.filter(c => c.time.startsWith(d))
    return { day: d, items }
  })
  return (
    <div className="card">
      <h3 style={{marginTop:0}}>Timetable</h3>
      <table className="table">
        <thead><tr><th>Day</th><th>Courses</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.day}>
              <td>{r.day}</td>
              <td>{r.items.length ? r.items.map(c => `${c.code} (${c.time.split(' ')[1]})`).join(', ') : '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function UserDashboard(){
  const { currentUser, logout, students, courses, addCourseToStudent, removeCourseFromStudent } = useApp()
  const nav = useNavigate()
  const me = students.find(s => s.id === currentUser?.id || s.email === currentUser?.email)

  const myCourses = useMemo(()=> (me?.courses || []).map(code => courses.find(c => c.code === code)).filter(Boolean), [me, courses])

  const [tab, setTab] = useState('courses') // courses, timetable, attendance, marks

  if(!me) return null

  const availableCourses = courses.filter(c => !me.courses.includes(c.code))

  return (
    <div className="user-shell">
      <div className="topbar">
        <div className="brand">Student Portal</div>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <span className="role-badge">Student: {me.name} ({me.id})</span>
          <button className="btn btn-danger" onClick={()=>{ logout(); nav('/'); }}>Logout</button>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <h3 style={{marginTop:0}}>Profile</h3>
          <div><b>Name:</b> {me.name}</div>
          <div><b>ID:</b> {me.id}</div>
          <div><b>Email:</b> {me.email}</div>
          <div><b>Department:</b> {me.dept}</div>
          <div><b>Attendance:</b> {me.attendance}%</div>
        </div>

        <div className="card">
          <h3 style={{marginTop:0}}>Quick Enroll</h3>
          <div style={{display:'flex', gap:8, flexWrap:'wrap'}}>
            <select className="input" style={{maxWidth:240}} defaultValue="" onChange={e=>{
              const code = e.target.value
              if(code) addCourseToStudent(me.id, code)
              e.target.value = ''
            }}>
              <option value="" disabled>Select course to add…</option>
              {availableCourses.map(c => <option key={c.code} value={c.code}>{c.code} — {c.title}</option>)}
            </select>
          </div>
          <div style={{marginTop:10, fontSize:12, color:'#666'}}>Note: system prevents time clashes and seat overflows.</div>
        </div>
      </div>

      <div className="card" style={{marginTop:18}}>
        <div className="tabs">
          {['courses','timetable','attendance','marks'].map(k => (
            <button key={k} className={\`tab-btn \${tab===k?'active':''}\`} onClick={()=>setTab(k)}>
              {k[0].toUpperCase()+k.slice(1)}
            </button>
          ))}
        </div>

        {tab==='courses' && (
          <div style={{overflow:'auto'}}>
            <table className="table">
              <thead><tr><th>Code</th><th>Title</th><th>Time</th><th>Action</th></tr></thead>
              <tbody>
                {myCourses.map(c => (
                  <tr key={c.code}>
                    <td>{c.code}</td><td>{c.title}</td><td>{c.time}</td>
                    <td><button className="btn btn-ghost" onClick={()=>removeCourseFromStudent(me.id, c.code)}>Drop</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab==='timetable' && <Timetable courses={myCourses} />}

        {tab==='attendance' && (
          <div className="grid">
            <AttendanceChart value={me.attendance} />
          </div>
        )}

        {tab==='marks' && (
          <div className="grid">
            <MarksChart marks={me.marks || {}} />
          </div>
        )}
      </div>
    </div>
  )
}
