import React, { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext'
import { useNavigate } from 'react-router-dom'

export default function AdminDashboard(){
  const { currentUser, logout, students, courses, addCourse, deleteCourse, addCourseToStudent, removeCourseFromStudent } = useApp()
  const nav = useNavigate()
  const [query, setQuery] = useState('')

  const filtered = useMemo(()=>{
    const q = query.trim().toLowerCase()
    if(!q) return students
    return students.filter(s => s.name.toLowerCase().includes(q) || s.id.toLowerCase().includes(q) || s.email.toLowerCase().includes(q))
  }, [students, query])

  const [newCourse, setNewCourse] = useState({ code:'', title:'', time:'Mon 09:00-11:00', seatsAvailable:20 })

  const handleAddCourse = (e)=>{
    e.preventDefault()
    if(!newCourse.code || !newCourse.title) return
    addCourse({ ...newCourse, seatsAvailable: Number(newCourse.seatsAvailable)||20 })
    setNewCourse({ code:'', title:'', time:'Mon 09:00-11:00', seatsAvailable:20 })
  }

  return (
    <div className="admin-shell">
      <div className="topbar">
        <div className="brand">Admin Dashboard</div>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <span className="role-badge">Admin: {currentUser?.name}</span>
          <button className="btn btn-danger" onClick={()=>{ logout(); nav('/'); }}>Logout</button>
        </div>
      </div>

      <div className="grid grid-2">
        {/* Left: Students */}
        <div className="card">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
            <h3 style={{margin:0}}>Students</h3>
            <div className="search-row">
              <input className="input" placeholder="Search by name, ID, or email" value={query} onChange={e=>setQuery(e.target.value)} />
            </div>
          </div>

          <div style={{maxHeight: '58vh', overflow:'auto'}}>
            <table className="table">
              <thead>
                <tr>
                  <th>ID</th><th>Name</th><th>Email</th><th>Dept</th><th>Registered Courses</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(st => {
                  const regCourses = st.courses
                  return (
                    <tr key={st.id}>
                      <td>{st.id}</td>
                      <td>{st.name}</td>
                      <td>{st.email}</td>
                      <td>{st.dept}</td>
                      <td>{regCourses.join(', ') || '-'}</td>
                      <td style={{display:'flex', gap:6, flexWrap:'wrap'}}>
                        {/* Add Course dropdown */}
                        <select className="input" style={{width:160}} defaultValue="" onChange={e=>{
                          const code = e.target.value
                          if(code) addCourseToStudent(st.id, code)
                          e.target.value = ''
                        }}>
                          <option value="" disabled>Add course…</option>
                          {courses.filter(c=>!regCourses.includes(c.code)).map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                        </select>

                        {/* Remove button per course */}
                        {regCourses.map(code => (
                          <button className="btn btn-ghost" key={code} onClick={()=>removeCourseFromStudent(st.id, code)}>Remove {code}</button>
                        ))}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Courses manage */}
        <div className="card">
          <h3 style={{marginTop:0}}>Manage Courses</h3>
          <form onSubmit={handleAddCourse} style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:12}}>
            <input className="input" placeholder="Code (e.g. CS202)" value={newCourse.code} onChange={e=>setNewCourse(v=>({...v, code:e.target.value.toUpperCase()}))} />
            <input className="input" placeholder="Title" value={newCourse.title} onChange={e=>setNewCourse(v=>({...v, title:e.target.value}))} />
            <input className="input" placeholder="Time (e.g. Tue 14:00-16:00)" value={newCourse.time} onChange={e=>setNewCourse(v=>({...v, time:e.target.value}))} />
            <input className="input" type="number" placeholder="Seats" value={newCourse.seatsAvailable} onChange={e=>setNewCourse(v=>({...v, seatsAvailable:e.target.value}))} />
            <div style={{gridColumn:'1 / -1'}}>
              <button className="btn btn-accent" type="submit">Add Course</button>
            </div>
          </form>

          <div style={{maxHeight:'52vh', overflow:'auto'}}>
            <table className="table">
              <thead>
                <tr>
                  <th>Code</th><th>Title</th><th>Time</th><th>Seats Left</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {courses.map(c => {
                  const left = (c.seatsAvailable ?? 0) - (c.seatsTaken ?? 0)
                  return (
                    <tr key={c.code}>
                      <td>{c.code}</td>
                      <td>{c.title}</td>
                      <td>{c.time}</td>
                      <td>{left}</td>
                      <td>
                        <button className="btn btn-danger" onClick={()=>deleteCourse(c.code)}>Delete</button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
