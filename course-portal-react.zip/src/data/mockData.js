export const defaultCourses = [
  { code: 'CS101', title: 'Intro to CS', time: 'Mon 09:00-11:00', seatsAvailable: 30, seatsTaken: 0 },
  { code: 'MA102', title: 'Calculus I', time: 'Tue 11:00-13:00', seatsAvailable: 25, seatsTaken: 0 },
  { code: 'EN103', title: 'English', time: 'Wed 09:00-11:00', seatsAvailable: 20, seatsTaken: 0 },
  { code: 'PH104', title: 'Physics', time: 'Thu 10:00-12:00', seatsAvailable: 25, seatsTaken: 0 },
]

export const defaultStudents = [
  {
    id: 'S101',
    name: 'Aryan Mehta',
    email: 'aryan@college.edu',
    password: 'aryan123',
    dept: 'CSE',
    attendance: 92,
    marks: { CS101: 86, MA102: 79, EN103: 82, PH104: 88 },
    courses: ['CS101', 'MA102']
  },
  {
    id: 'S102',
    name: 'Priya Rao',
    email: 'priya@college.edu',
    password: 'priya123',
    dept: 'ECE',
    attendance: 88,
    marks: { CS101: 72, MA102: 81, EN103: 75, PH104: 79 },
    courses: ['EN103']
  },
  {
    id: 'S103',
    name: 'Rohan Das',
    email: 'rohan@college.edu',
    password: 'rohan123',
    dept: 'ME',
    attendance: 76,
    marks: { CS101: 65, MA102: 69, EN103: 70, PH104: 68 },
    courses: ['PH104']
  },
  {
    id: 'S104',
    name: 'Neha Sharma',
    email: 'neha@college.edu',
    password: 'neha123',
    dept: 'IT',
    attendance: 81,
    marks: { CS101: 74, MA102: 71, EN103: 77, PH104: 73 },
    courses: []
  },
]

export const defaultAdmins = [
  { email: 'admin@college.edu', password: 'admin123', role: 'admin', name: 'System Admin' },
]
