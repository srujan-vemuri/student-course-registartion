import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './components/Login'
import AdminDashboard from './components/AdminDashboard'
import UserDashboard from './components/UserDashboard'
import { useApp } from './context/AppContext'

export default function App() {
  const { currentUser } = useApp()

  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route
        path="/admin"
        element={currentUser?.role === 'admin' ? <AdminDashboard /> : <Navigate to="/" replace />}
      />
      <Route
        path="/user"
        element={currentUser?.role === 'student' ? <UserDashboard /> : <Navigate to="/" replace />}
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
